## Activity 2: Debug Console

Last three build() called lines:

    build() called: 4 glasses
    build() called: 5 glasses
    build() called: 6 glasses

## Activity 3: Expanded Experiment

    When I removed Expanded from one StatBox, the boxes no longer shared the available width evenly, and the layout could overflow. Expanded helps the widgets divide the available horizontal space. I restored Expanded after the experiment.

## Activity 5 Observation

    I changed the ElevatedButton corner radius from 8 to 20 in buildTheme(). The buttons became more rounded. Since the style is defined in ThemeData, it can be applied consistently to ElevatedButton widgets throughout the app. The dark-mode switch changes the appearance of the whole app between light and dark themes.

## Review Questions – Flutter Architecture, Widgets and Basic UI

    1. What is the difference between a StatelessWidget and a StatefulWidget? Give one example of each from this lab.

    - A StatelessWidget does not manage changing state, while a StatefulWidget can update its appearance when its data changes. An example of a StatelessWidget is the profile card in Activity 1. An example of a StatefulWidget is the water tracker in Activity 2.

    2. Why is a StatefulWidget written as two classes? What does each class do?

    - A StatefulWidget uses two classes because they have different responsibilities. The first class defines the widget, while the second class extends State and holds the changing data and the code that updates the interface.

    3. In Activity 2, what happened when you changed _glasses outside setState()? Why?

    - When _glasses was changed outside setState(), the displayed number and progress bar did not update immediately. This happened because Flutter was not notified that the interface needed to be rebuilt.

    4. Looking at the Debug Console in Activity 2, when is build() called?

    - The build() method is called when Flutter creates the interface and when the widget needs to rebuild, such as after setState() updates the water tracker. It may also be called for other framework-related updates.

    5. Explain the main axis and the cross axis of a Row and of a Column.

    - In a Row, the main axis runs horizontally and the cross axis runs vertically. In a Column, the main axis runs vertically and the cross axis runs horizontally. Properties such as mainAxisAlignment and crossAxisAlignment control how children are positioned along these axes.

    6. In Activity 3, what happened when you removed Expanded from a StatBox? What does Expanded do?

    - When Expanded was removed, the layout could become uneven or overflow because the widgets no longer shared the available space in the same way. Expanded makes a child take up the available space within a Row or Column, helping the layout fit properly.

    7. Why do we use GridView.builder for the menu instead of a Column with many children?

    - GridView.builder displays menu items in a grid and can build items as they are needed while scrolling. It is more suitable for many menu items because it supports scrolling and uses space more efficiently than a long Column.

    8. How do Stack and Positioned create the Best seller badge in Activity 4?

    - Stack allows widgets to overlap each other. Positioned places the Best seller badge at a specific location inside the menu card, such as the top-left corner, so it appears over the menu item.

    9. What is the difference between customizing with ThemeData and with a style on one widget? Give one example of each from Activity 5.

    - ThemeData customizes the appearance of widgets throughout the app, while a style applied directly to one widget affects only that widget. In Activity 5, elevatedButtonTheme sets the general style for elevated buttons, while a TextStyle applied directly to a particular Text widget would customize only that text.

    10. When you flip the dark-mode switch in Activity 5, which widget holds the state, and how does the change reach MaterialApp?

    - The _ThemeDemoAppState class holds the _isDark state. When the switch is flipped, SettingsPage calls the onDarkChanged callback, which runs _setDark() in the parent widget. The method uses setState() to update _isDark, and MaterialApp rebuilds with the appropriate themeMode, changing the app between light and dark mode.

## GitHub Repo Link
    https://github.com/JherickPenalosa/flutter_basics_lab.git